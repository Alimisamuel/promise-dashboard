"use strict";
exports.id = 18;
exports.ids = [18];
exports.modules = {

/***/ 7964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);



// import { noCase } from "change-case";
// import { faker } from "@faker-js/faker";

// @mui

// utils
// import { fToNow } from "../../../utils/formatTime";
// components
// import Iconify from "../../../components/iconify";
// import Scrollbar from "../../../components/scrollbar";
// ----------------------------------------------------------------------
const NOTIFICATIONS = [
    {
        id: 0,
        title: "Your order is placed",
        description: "waiting for shipping",
        avatar: null,
        type: "order_placed",
        createdAt: (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.set)(new Date(), {
            hours: 10,
            minutes: 30
        }),
        isUnRead: true
    },
    {
        id: 1,
        title: "samuel",
        description: "answered to your comment on the Minimal",
        avatar: "/assets/images/avatars/avatar_2.jpg",
        type: "friend_interactive",
        createdAt: (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.sub)(new Date(), {
            hours: 3,
            minutes: 30
        }),
        isUnRead: true
    },
    {
        id: 2,
        title: "You have new message",
        description: "5 unread messages",
        avatar: null,
        type: "chat_message",
        createdAt: (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.sub)(new Date(), {
            days: 1,
            hours: 3,
            minutes: 30
        }),
        isUnRead: false
    },
    {
        id: 3,
        title: "You have new mail",
        description: "sent from Guido Padberg",
        avatar: null,
        type: "mail",
        createdAt: (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.sub)(new Date(), {
            days: 2,
            hours: 3,
            minutes: 30
        }),
        isUnRead: false
    },
    {
        id: 4,
        title: "Delivery processing",
        description: "Your order is being shipped",
        avatar: null,
        type: "order_shipped",
        createdAt: (0,date_fns__WEBPACK_IMPORTED_MODULE_2__.sub)(new Date(), {
            days: 3,
            hours: 3,
            minutes: 30
        }),
        isUnRead: false
    }, 
];
function NotificationsPopover() {
    const { 0: notifications , 1: setNotifications  } = useState(NOTIFICATIONS);
    const totalUnRead = notifications.filter((item)=>item.isUnRead === true).length;
    const { 0: open , 1: setOpen  } = useState(null);
    const handleOpen = (event)=>{
        setOpen(event.currentTarget);
    };
    const handleClose = ()=>{
        setOpen(null);
    };
    const handleMarkAllAsRead = ()=>{
        setNotifications(notifications.map((notification)=>({
                ...notification,
                isUnRead: false
            })));
    };
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx(IconButton, {
                color: open ? "primary" : "default",
                onClick: handleOpen,
                sx: {
                    width: 40,
                    height: 40
                },
                children: /*#__PURE__*/ _jsx(Badge, {
                    badgeContent: totalUnRead,
                    color: "error"
                })
            }),
            /*#__PURE__*/ _jsxs(Popover, {
                open: Boolean(open),
                anchorEl: open,
                onClose: handleClose,
                anchorOrigin: {
                    vertical: "bottom",
                    horizontal: "right"
                },
                transformOrigin: {
                    vertical: "top",
                    horizontal: "right"
                },
                PaperProps: {
                    sx: {
                        mt: 1.5,
                        ml: 0.75,
                        width: 360
                    }
                },
                children: [
                    /*#__PURE__*/ _jsxs(Box, {
                        sx: {
                            display: "flex",
                            alignItems: "center",
                            py: 2,
                            px: 2.5
                        },
                        children: [
                            /*#__PURE__*/ _jsxs(Box, {
                                sx: {
                                    flexGrow: 1
                                },
                                children: [
                                    /*#__PURE__*/ _jsx(Typography, {
                                        variant: "subtitle1",
                                        children: "Notifications"
                                    }),
                                    /*#__PURE__*/ _jsxs(Typography, {
                                        variant: "body2",
                                        sx: {
                                            color: "text.secondary"
                                        },
                                        children: [
                                            "You have ",
                                            totalUnRead,
                                            " unread messages"
                                        ]
                                    })
                                ]
                            }),
                            totalUnRead > 0 && /*#__PURE__*/ _jsx(Tooltip, {
                                title: " Mark all as read",
                                children: /*#__PURE__*/ _jsx(IconButton, {
                                    color: "primary",
                                    onClick: handleMarkAllAsRead
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx(Divider, {
                        sx: {
                            borderStyle: "dashed"
                        }
                    }),
                    /*#__PURE__*/ _jsx(List, {
                        disablePadding: true,
                        subheader: /*#__PURE__*/ _jsx(ListSubheader, {
                            disableSticky: true,
                            sx: {
                                py: 1,
                                px: 2.5,
                                typography: "overline"
                            },
                            children: "New"
                        }),
                        children: notifications.slice(0, 2).map((notification)=>/*#__PURE__*/ _jsx(NotificationItem, {
                                notification: notification
                            }, notification.id))
                    }),
                    /*#__PURE__*/ _jsx(List, {
                        disablePadding: true,
                        subheader: /*#__PURE__*/ _jsx(ListSubheader, {
                            disableSticky: true,
                            sx: {
                                py: 1,
                                px: 2.5,
                                typography: "overline"
                            },
                            children: "Before that"
                        }),
                        children: notifications.slice(2, 5).map((notification)=>/*#__PURE__*/ _jsx(NotificationItem, {
                                notification: notification
                            }, notification.id))
                    }),
                    /*#__PURE__*/ _jsx(Divider, {
                        sx: {
                            borderStyle: "dashed"
                        }
                    }),
                    /*#__PURE__*/ _jsx(Box, {
                        sx: {
                            p: 1
                        },
                        children: /*#__PURE__*/ _jsx(Button, {
                            fullWidth: true,
                            disableRipple: true,
                            children: "View All"
                        })
                    })
                ]
            })
        ]
    });
};
// ----------------------------------------------------------------------
NotificationItem.propTypes = {
    notification: prop_types__WEBPACK_IMPORTED_MODULE_1___default().shape({
        createdAt: prop_types__WEBPACK_IMPORTED_MODULE_1___default().instanceOf(Date),
        id: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        isUnRead: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool),
        title: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        description: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        type: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),
        avatar: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().any)
    })
};
function NotificationItem({ notification  }) {
    const { avatar , title  } = renderContent(notification);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItemButton, {
        sx: {
            py: 1.5,
            px: 2.5,
            mt: "1px",
            ...notification.isUnRead && {
                bgcolor: "action.selected"
            }
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItemAvatar, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Avatar, {
                    sx: {
                        bgcolor: "background.neutral"
                    },
                    children: avatar
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.ListItemText, {
                primary: title,
                secondary: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                    variant: "caption",
                    sx: {
                        mt: 0.5,
                        display: "flex",
                        alignItems: "center",
                        color: "text.disabled"
                    },
                    children: fToNow(notification.createdAt)
                })
            })
        ]
    });
}
// ----------------------------------------------------------------------
function renderContent(notification) {
    const title = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
        variant: "subtitle2",
        children: [
            notification.title,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                component: "span",
                variant: "body2",
                sx: {
                    color: "text.secondary"
                },
                children: [
                    "\xa0 ",
                    noCase(notification.description)
                ]
            })
        ]
    });
    if (notification.type === "order_placed") {
        return {
            avatar: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                alt: notification.title,
                src: "/assets/icons/ic_notification_package.svg"
            }),
            title
        };
    }
    if (notification.type === "order_shipped") {
        return {
            avatar: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                alt: notification.title,
                src: "/assets/icons/ic_notification_shipping.svg"
            }),
            title
        };
    }
    if (notification.type === "mail") {
        return {
            avatar: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                alt: notification.title,
                src: "/assets/icons/ic_notification_mail.svg"
            }),
            title
        };
    }
    if (notification.type === "chat_message") {
        return {
            avatar: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                alt: notification.title,
                src: "/assets/icons/ic_notification_chat.svg"
            }),
            title
        };
    }
    return {
        avatar: notification.avatar ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            alt: notification.title,
            src: notification.avatar
        }) : null,
        title
    };
}


/***/ }),

/***/ 2894:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ AccountPopover)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _contexts_auth_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5462);
/* harmony import */ var _lib_auth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7082);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_auth_context__WEBPACK_IMPORTED_MODULE_6__, _lib_auth__WEBPACK_IMPORTED_MODULE_7__]);
([_contexts_auth_context__WEBPACK_IMPORTED_MODULE_6__, _lib_auth__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const AccountPopover = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { anchorEl , onClose , open , ...other } = props;
    const authContext = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_auth_context__WEBPACK_IMPORTED_MODULE_6__/* .AuthContext */ .Vo);
    const userInfo = JSON.parse(window.localStorage.getItem("user-info"));
    console.log(userInfo.admin);
    const handleLogout = ()=>{
        router.push("/login");
        localStorage.clear();
    };
    const handleSignOut = async ()=>{
        onClose?.();
        // Check if authentication with Zalter is enabled
        // If not enabled, then redirect is not required
        if (!_lib_auth__WEBPACK_IMPORTED_MODULE_7__/* .ENABLE_AUTH */ .P) {
            return;
        }
        // Check if auth has been skipped
        // From sign-in page we may have set "skip-auth" to "true"
        // If this has been skipped, then redirect to "sign-in" directly
        const authSkipped = globalThis.sessionStorage.getItem("skip-auth") === "true";
        if (authSkipped) {
            // Cleanup the skip auth state
            globalThis.sessionStorage.removeItem("skip-auth");
            // Redirect to sign-in page
            next_router__WEBPACK_IMPORTED_MODULE_2___default().push("/sign-in").catch(console.error);
            return;
        }
        try {
            // This can be call inside AuthProvider component, but we do it here for simplicity
            await _lib_auth__WEBPACK_IMPORTED_MODULE_7__/* .auth.signOut */ .I.signOut();
            // Update Auth Context state
            authContext.signOut();
            // Redirect to sign-in page
            next_router__WEBPACK_IMPORTED_MODULE_2___default().push("/sign-in").catch(console.error);
        } catch (err) {
            console.error(err);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Popover, {
        anchorEl: anchorEl,
        anchorOrigin: {
            horizontal: "left",
            vertical: "bottom"
        },
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                width: "300px"
            }
        },
        ...other,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box, {
                sx: {
                    py: 1.5,
                    px: 2
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: "/account",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                            variant: "overline",
                            sx: {
                                cursor: "pointer"
                            },
                            children: "Account"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                        color: "text.secondary",
                        variant: "body2",
                        children: userInfo.admin
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.MenuList, {
                disablePadding: true,
                sx: {
                    "& > *": {
                        "&:first-of-type": {
                            borderTopColor: "divider",
                            borderTopStyle: "solid",
                            borderTopWidth: "1px"
                        },
                        padding: "12px 16px"
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.MenuItem, {
                    onClick: handleLogout,
                    children: "Sign out"
                })
            })
        ]
    });
};
AccountPopover.propTypes = {
    anchorEl: (prop_types__WEBPACK_IMPORTED_MODULE_3___default().any),
    onClose: (prop_types__WEBPACK_IMPORTED_MODULE_3___default().func),
    open: (prop_types__WEBPACK_IMPORTED_MODULE_3___default().bool.isRequired)
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3018:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ DashboardLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7333);
/* harmony import */ var _dashboard_navbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4192);
/* harmony import */ var _dashboard_sidebar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3698);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_auth_guard__WEBPACK_IMPORTED_MODULE_4__, _dashboard_navbar__WEBPACK_IMPORTED_MODULE_5__]);
([_auth_guard__WEBPACK_IMPORTED_MODULE_4__, _dashboard_navbar__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const DashboardLayoutRoot = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.styled)("div")(({ theme  })=>({
        display: "flex",
        flex: "1 1 auto",
        maxWidth: "100%",
        paddingTop: 64,
        [theme.breakpoints.up("lg")]: {
            paddingLeft: 280
        }
    }));
const DashboardLayout = (props)=>{
    const { children  } = props;
    const { 0: isSidebarOpen , 1: setSidebarOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_auth_guard__WEBPACK_IMPORTED_MODULE_4__/* .AuthGuard */ .a, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DashboardLayoutRoot, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    sx: {
                        display: "flex",
                        flex: "1 1 auto",
                        flexDirection: "column",
                        width: "100%"
                    },
                    children: children
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_navbar__WEBPACK_IMPORTED_MODULE_5__/* .DashboardNavbar */ .h, {
                onSidebarOpen: ()=>setSidebarOpen(true)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dashboard_sidebar__WEBPACK_IMPORTED_MODULE_6__/* .DashboardSidebar */ .g, {
                onClose: ()=>setSidebarOpen(false),
                open: isSidebarOpen
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4192:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ DashboardNavbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3365);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _icons_bell__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6395);
/* harmony import */ var _icons_user_circle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4433);
/* harmony import */ var _icons_users__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7514);
/* harmony import */ var _account_popover__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2894);
/* harmony import */ var _Notification__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7964);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_account_popover__WEBPACK_IMPORTED_MODULE_10__]);
_account_popover__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const DashboardNavbarRoot = _emotion_styled__WEBPACK_IMPORTED_MODULE_3___default()(_mui_material__WEBPACK_IMPORTED_MODULE_4__.AppBar)(({ theme  })=>({
        backgroundColor: theme.palette.background.paper,
        boxShadow: theme.shadows[3]
    }));
const DashboardNavbar = (props)=>{
    const { onSidebarOpen , ...other } = props;
    const settingsRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { 0: openAccountPopover , 1: setOpenAccountPopover  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const USER = JSON.parse(window.localStorage.getItem("user-info"));
    const info = USER.data;
    // const userInfo = JSON.parse(window.localStorage.getItem('user-info'));
    const avater = info.fullName.charAt(0);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DashboardNavbarRoot, {
                sx: {
                    left: {
                        lg: 280
                    },
                    width: {
                        lg: "calc(100% - 280px)"
                    }
                },
                ...other,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Toolbar, {
                    disableGutters: true,
                    sx: {
                        minHeight: 64,
                        left: 0,
                        px: 2
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                            onClick: onSidebarOpen,
                            sx: {
                                display: {
                                    xs: "inline-flex",
                                    lg: "none"
                                }
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_5___default()), {
                                fontSize: "small"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
                            title: "Search",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                sx: {
                                    ml: 1
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    fontSize: "small"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Box, {
                            sx: {
                                flexGrow: 1
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
                            title: "Contacts",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                sx: {
                                    ml: 1
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons_users__WEBPACK_IMPORTED_MODULE_9__/* .Users */ .Q, {
                                    fontSize: "small"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
                            title: "Notifications",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                sx: {
                                    ml: 1
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Badge, {
                                    badgeContent: 4,
                                    color: "primary",
                                    variant: "dot",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons_bell__WEBPACK_IMPORTED_MODULE_7__/* .Bell */ .U, {
                                        fontSize: "small"
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Avatar, {
                            onClick: ()=>setOpenAccountPopover(true),
                            ref: settingsRef,
                            sx: {
                                cursor: "pointer",
                                height: 40,
                                width: 40,
                                ml: 1
                            },
                            children: avater
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_account_popover__WEBPACK_IMPORTED_MODULE_10__/* .AccountPopover */ .x, {
                anchorEl: settingsRef.current,
                open: openAccountPopover,
                onClose: ()=>setOpenAccountPopover(false)
            })
        ]
    });
};
DashboardNavbar.propTypes = {
    onSidebarOpen: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().func)
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3698:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ DashboardSidebar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_OpenInNew__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2596);
/* harmony import */ var _mui_icons_material_OpenInNew__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_OpenInNew__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _icons_chart_bar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3351);
/* harmony import */ var _icons_cog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7479);
/* harmony import */ var _icons_lock__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(937);
/* harmony import */ var _icons_selector__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4140);
/* harmony import */ var _icons_shopping_bag__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1832);
/* harmony import */ var _icons_user__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3397);
/* harmony import */ var _icons_user_add__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1187);
/* harmony import */ var _icons_users__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7514);
/* harmony import */ var _icons_x_circle__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1946);
/* harmony import */ var _icons_user_circle__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4433);
/* harmony import */ var _public_static_images_avatars_avatar_2_png__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8843);
/* harmony import */ var _public_static_logo_png__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4157);
/* harmony import */ var _nav_item__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9346);





















const items = [
    {
        href: "/",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons_chart_bar__WEBPACK_IMPORTED_MODULE_8__/* .ChartBar */ .B, {
            fontSize: "small"
        }),
        title: "Dashboard"
    },
    {
        href: "/students",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons_users__WEBPACK_IMPORTED_MODULE_15__/* .Users */ .Q, {
            fontSize: "small"
        }),
        title: "Students"
    },
    {
        href: "/teacher-mgt",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_icons_users__WEBPACK_IMPORTED_MODULE_15__/* .Users */ .Q, {
            fontSize: "small"
        }),
        title: "Teachers"
    }, 
];
const DashboardSidebar = (props)=>{
    // const userInfo = JSON.parse(window.localStorage.getItem('user-info'));
    const USER = JSON.parse(window.localStorage.getItem("user-info"));
    const info = USER.data;
    const avatar = info.fullName.charAt(0);
    const { open , onClose  } = props;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const lgUp = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.useMediaQuery)((theme)=>theme.breakpoints.up("lg"), {
        defaultMatches: true,
        noSsr: false
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!router.isReady) {
            return;
        }
        if (open) {
            onClose?.();
        }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        router.asPath
    ]);
    const content = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
            sx: {
                bgcolor: "#0373a3",
                display: "flex",
                flexDirection: "column",
                height: "100%"
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                            sx: {
                                p: 3
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    src: _public_static_logo_png__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z,
                                    width: 60,
                                    height: 60
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                            sx: {
                                px: 2
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                sx: {
                                    alignItems: "center",
                                    backgroundColor: "rgba(255, 255, 255, 0.04)",
                                    cursor: "pointer",
                                    display: "flex",
                                    justifyContent: "space-between",
                                    px: 3,
                                    py: "11px",
                                    borderRadius: 1
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Avatar, {
                                        sx: {
                                            cursor: "pointer",
                                            height: 60,
                                            width: 60,
                                            ml: 1
                                        },
                                        children: avatar
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {
                                            variant: "body1",
                                            children: info.fullName
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Divider, {
                    sx: {
                        borderColor: "#2D3748",
                        my: 3
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                    sx: {
                        flexGrow: 1
                    },
                    children: items.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_nav_item__WEBPACK_IMPORTED_MODULE_20__/* .NavItem */ .L, {
                            icon: item.icon,
                            href: item.href,
                            title: item.title
                        }, item.title))
                })
            ]
        })
    });
    if (lgUp) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Drawer, {
            anchor: "left",
            open: true,
            PaperProps: {
                sx: {
                    backgroundColor: "neutral.900",
                    color: "#FFFFFF",
                    width: 280
                }
            },
            variant: "permanent",
            children: content
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Drawer, {
        anchor: "left",
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                backgroundColor: "neutral.900",
                color: "#FFFFFF",
                width: 280
            }
        },
        sx: {
            zIndex: (theme)=>theme.zIndex.appBar + 100
        },
        variant: "temporary",
        children: content
    });
};
DashboardSidebar.propTypes = {
    onClose: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().func),
    open: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().bool)
};


/***/ })

};
;